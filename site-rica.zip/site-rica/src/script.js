// Smooth Scroll para os links de navegação
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Animação de Fade-in ao Rolar
const fadeIns = document.querySelectorAll('.fade-in');
const observerOptions = {
    threshold: 0.5, // Mostrar animação quando 50% do elemento for visível
    rootMargin: "0px 0px -100px 0px"
};

const fadeInOnScroll = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('appear');
        observer.unobserve(entry.target);
    });
}, observerOptions);

fadeIns.forEach(fadeIn => {
    fadeInOnScroll.observe(fadeIn);
});

// Modal Popup para o Formulário de Contato
const btnOpenModal = document.querySelector('.btn');
const modal = document.createElement('div');
modal.classList.add('modal');
modal.innerHTML = `
    <div class="modal-content">
        <span class="close-button">&times;</span>
        <h2>Agende uma Consulta</h2>
        <p>Entre em contato para agendar uma consulta com Érica Rodrigues.</p>
        <form>
            <label for="name">Nome:</label>
            <input type="text" id="name" name="name" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <button type="submit" class="btn-submit">Enviar</button>
        </form>
    </div>
`;

document.body.appendChild(modal);

btnOpenModal.addEventListener('click', (e) => {
    e.preventDefault();
    modal.style.display = 'block';
});

modal.querySelector('.close-button').addEventListener('click', () => {
    modal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});
